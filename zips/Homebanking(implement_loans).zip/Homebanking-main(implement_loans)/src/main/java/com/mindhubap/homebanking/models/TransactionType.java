package com.mindhubap.homebanking.models;

public enum TransactionType {

    CREDIT,
    DEBIT,
}
